import React from "react"
import Navbar from "../../components/shared/Navbar";
import './confiteria.css';

const Confiteria =()=>{
    return(
        <Navbar/>
    )
}

export default Confiteria;