import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import PeliculaHeader from "../../components/PeliculaHeader";
import Navbar from "../../components/shared/Navbar";
import DetallesPelicula from "../../components/DetallesPelicula";
import "./infopelicula.css";

const peliculasDB = [
    {
        id: 1,
        titulo: "Alerta Roja",
        fechaEstreno: "12 Noviembre 2021",
        genero: "Acción, Comedia",
        clasificacionEdad: "Recomendada para Mayores de 15 años",
        duracion: "1h 58min",
        poster: "/img/cartelera/alerta_roja.jpg",
        imagenFondo: "/img/headers/alerta_roja.jpg",
        sinopsis: "En el momento en que salta una nueva alerta roja enviada por la Interpol, todos los departamentos de policía del mundo se ponen en guardia. En esta ocasión el objetivo será atrapar a la ladrona de arte más buscada del planeta. El FBI decide poner en el caso a su mejor agente, John Hartley (Dwayne 'La Roca' Johnson). Sin embargo, tras un temerario atraco todo se complica y termina uniéndose a un criminal, Nolan Booth (Ryan Reynolds), con la intención de lograr detener a la fugitiva (Gal Gadot). Una coincidencia hará que todo cambie. Este particular trío deberá enfrentarse a una gran cantidad de peligros, como la jungla o una prisión, pero lo peor de todo es que tendrán que mantenerse unidos durante todo el tiempo.",
        protagonistas: ["Dwayne Johnson", "Ryan Reynolds", "Gal Gadot"],
        director: "Rawson Marshall Thurber",
        idioma: "Inglés"
    },
    {
        id: 2,
        titulo: "Black Panther 2: Wakanda Forever",
        fechaEstreno: "11 Noviembre 2022",
        genero: "Acción, Aventura, Ciencia ficción",
        clasificacionEdad: "Recomendada para Mayores de 12 años",
        duracion: "2h 43min",
        poster: "/img/cartelera/black_panther.jpg",
        imagenFondo: "/img/headers/black_panther.jpg",
        sinopsis: "La reina Ramonda (Angela Bassett), Shuri (Letitia Wright), M’Baku (Winston Duke), Okoye (Danai Gurira) y las Dora Milaje (incluida Florence Kasumba), luchan para proteger su nación de la injerencia de potencias mundiales a raíz de la muerte del rey T’Challa. Mientras los wakandianos se esfuerzan por adaptarse a su nueva etapa, los héroes deben actuar unidos, con la ayuda del Perro de la Guerra Nakia (Lupita Nyong’o) y Everett Ross (Martin Freeman), y forzar un nuevo destino para el reino de Wakanda.",
        protagonistas: ["Letita Wright", "Lupia Nyong'o", "Dania Gurira", "Tenoch Huerta"],
        director: "Ryan Coogler",
        idioma: "Inglés"
    }
];

const InfoPelicula = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  });

    const { id } = useParams();

    const datosPelicula = peliculasDB.find(p => p.id === parseInt(id));

    if (!datosPelicula) {
        return (
          <>
            <Navbar/>
            <div className="error">
              Película no disponible
            </div>
          </>
        )
    }

    return (
      <>
        <Navbar/>
        <div className="info-pelicula">
          <PeliculaHeader
            titulo={datosPelicula.titulo}
            fechaEstreno={datosPelicula.fechaEstreno}
            genero={datosPelicula.genero}
            clasificacionEdad={datosPelicula.clasificacionEdad}
            duracion={datosPelicula.duracion}
            poster={datosPelicula.poster}
            imagenFondo={datosPelicula.imagenFondo}
          />
          <DetallesPelicula
            sinopsis={datosPelicula.sinopsis}
            protagonistas={datosPelicula.protagonistas}
            director={datosPelicula.director}
            idioma={datosPelicula.idioma}
          />
        </div>
      </>
    );
};

export default InfoPelicula;