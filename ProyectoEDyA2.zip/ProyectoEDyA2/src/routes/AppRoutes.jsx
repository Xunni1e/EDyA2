import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";

import Cartelera from "../pages/cartelera/cartelera";
import Estrenos from "../pages/estrenos/estrenos";
import Confiteria from "../pages/confiteria/confiteria";
import InfoPelicula from "../pages/infopelicula/infopelicula";
const router = createBrowserRouter([
    {
        path:"/",
        element: <Cartelera/>
    },
    {
        path:"/estrenos",
        element: <Estrenos/>
    },
    {
        path:"/confiteria",
        element: <Confiteria/>
    },
    {
        path:"/pelicula/:id",
        element: <InfoPelicula/>
    }
])

const rutas=()=>{
    return (
        <RouterProvider router={router} />
    )
}
export default rutas